package com.example.conf_serv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfServApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConfServApplication.class, args);
    }

}
