package com.isi.msformation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsFormationApplicationTests {

    @Test
    void contextLoads() {
    }

}
